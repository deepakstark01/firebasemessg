// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// import { getMessaging} from 'firebase/messaging';
import { getMessaging, getToken,onMessage} from 'firebase/messaging';
const firebaseConfig = {
  apiKey: "AIzaSyBcj72MKElFyPjyfxVuiIddkyWzjgQSRN4",
  authDomain: "automartz-demo.firebaseapp.com",
  projectId: "automartz-demo",
  storageBucket: "automartz-demo.appspot.com",
  messagingSenderId: "806161703728",
  appId: "1:806161703728:web:008d42d7c05dbc259b1ef5"
};
export const requestForToken = () => {
  return getToken(messaging, { vapidKey: 'BK8fAJzz9GbML5icDnRCmdheo2ExxLgWNT9xG26EpxFCHc41NIc5X41hv3OG3qFp8Q-eG_ZFQF_RaS_OSKB22nw' })
    .then((currentToken) => {
      if (currentToken) {
        console.log('current token for client: ', currentToken);
        // Perform any other neccessary action with the token
      } else {
        // Show permission request UI
        console.log('No registration token available. Request permission to generate one.');
      }
    })
    .catch((err) => {
      console.log('An error occurred while retrieving token. ', err);
    });
};
export const onMessageListener = () =>
  new Promise((resolve) => {
    onMessage(messaging, (payload) => {
      console.log("payload", payload)
      resolve(payload);
    });
  });
 initializeApp(firebaseConfig);
const messaging = getMessaging();
